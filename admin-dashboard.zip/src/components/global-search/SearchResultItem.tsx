import { useProductDetailsStore } from "@/stores/productDetailsStore";
import { Link } from "react-router-dom";

interface SearchResultItemProps {
  title: string;

  subtitle?: string;

  image?: string;

  href?: string;

  productId?: number;

  onClick?: () => void;
}

export function SearchResultItem({
  title,
  subtitle,
  image,
  href,
  productId,
  onClick,
}: SearchResultItemProps) {
  const { openModal } = useProductDetailsStore();
  return (
    <button
      type="button"
      onClick={() => {
        if (productId) {
          openModal(productId);
        }

        onClick?.();
      }}
      className="flex w-full items-center gap-3 rounded-2xl p-3 text-left transition-colors hover:bg-accent hover:text-accent-foreground"
    >
      {image && (
        <img
          src={image}
          alt={title}
          className="h-10 w-10 rounded-md object-cover"
        />
      )}

      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium">{title}</p>

        {subtitle && (
          <p className="text-xs text-muted-foreground">{subtitle}</p>
        )}
      </div>
    </button>
  );
}
